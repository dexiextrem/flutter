// lib/models/article.dart (ΔΙΟΡΘΩΜΕΝΟ)

class Article {
  // ΑΛΛΑΓΗ: Ο τύπος του ID πρέπει να είναι int για να λειτουργεί με τη λογική του Provider
  final int id; 
  final String title;
  final String date;
  final String image;
  final String content;
  final String tag;

  Article({
    required this.id,
    required this.title,
    required this.date,
    required this.image,
    required this.content,
    required this.tag,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    // Χειρισμός του ID: Μετατροπή σε int. Εάν είναι String, χρησιμοποιούμε int.tryParse().
    int parsedId;
    if (json['id'] is int) {
        parsedId = json['id'] as int;
    } else if (json['id'] is String) {
        parsedId = int.tryParse(json['id']) ?? 0; // Χρησιμοποιούμε 0 αν αποτύχει η μετατροπή
    } else {
        parsedId = 0;
    }

    return Article(
      // Χρησιμοποιούμε τον διορθωμένο, ακέραιο ID
      id: parsedId, 
      title: json['title'] ?? 'Χωρίς τίτλο',
      date: json['date'] ?? '',
      image: json['image'] ?? 'https://via.placeholder.com/600x400',
      content: json['content'] ?? '',
      tag: json['tag'] as String? ?? 'Γενικά',
    );
  }
}