// lib/main.dart (ΤΟ ΝΕΟ ΑΡΧΕΙΟ)

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// Imports των απαραίτητων αρχείων
import 'providers/theme_provider.dart';
import 'screens/splash_screen.dart'; // Η πρώτη οθόνη που θα φορτώσει

void main() {
  // Χρησιμοποιούμε ProviderScope για να ενεργοποιήσουμε το Riverpod σε όλη την εφαρμογή
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Παρακολούθηση του τρέχοντος ThemeMode (system, light, dark)
    final themeMode = ref.watch(themeProvider);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HVA News Portal',
      
      // Εφαρμογή του ThemeMode, LightTheme και DarkTheme
      themeMode: themeMode,
      theme: lightTheme,
      darkTheme: darkTheme,
      
      // Η αρχική οθόνη της εφαρμογής είναι το Splash Screen
      home: const SplashScreen(), 
    );
  }
}