// lib/widgets/gradient_background.dart

import 'package:flutter/material.dart';

class GradientBackground extends StatelessWidget {
  final Widget child;
  
  // Το gradient θα είναι από μωβ σε λευκό (για light mode) ή σε σκούρο γκρι (για dark mode)
  const GradientBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    // 1. Βρίσκουμε το χρώμα που έχει το Scaffold (βάση της οθόνης)
    final scaffoldColor = Theme.of(context).scaffoldBackgroundColor;
    
    // 2. Το χρώμα εκκίνησης θα είναι πάντα ένα βαθύ μωβ (Deep Purple)
    final Color startColor = Theme.of(context).primaryColorDark; 

    return Container(
      // Χρησιμοποιούμε το Decoration για να εφαρμόσουμε το gradient
      decoration: BoxDecoration(
        gradient: LinearGradient(
          // Το gradient ξεκινάει από πάνω (top center)
          begin: Alignment.topCenter,
          // και τελειώνει στο κάτω μέρος (bottom center)
          end: Alignment.bottomCenter,
          colors: [
            startColor.withOpacity(0.9), // Έντονο μωβ στην κορυφή
            startColor.withOpacity(0.5), // Πιο ανοιχτό μωβ στη μέση
            scaffoldColor,               // Σβήσιμο στο χρώμα του φόντου (λευκό/γκρι)
            scaffoldColor,               // Το κάτω μέρος παραμένει στο χρώμα του φόντου
          ],
          // Μικρή στάση για να ξεκινήσει πιο γρήγορα το σβήσιμο
          stops: const [0.0, 0.4, 0.9, 1.0], 
        ),
      ),
      // Εδώ βάζουμε το περιεχόμενο της οθόνης
      child: child,
    );
  }
}