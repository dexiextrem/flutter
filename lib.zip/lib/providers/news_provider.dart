// lib/providers/news_provider.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

// <--- ΠΡΟΣΘΗΚΗ: Εισάγουμε το μοντέλο Article από τον φάκελο models --->
import 'package:hva_news_app/models/article.dart';


// Ορισμός της αρχικής κατάστασης (State) του NewsNotifier
class NewsState {
  final List<Article> articles; // Η τρέχουσα λίστα άρθρων
  final bool isLoading;         // Αν γίνεται φόρτωση
  final bool hasMore;           // Αν υπάρχουν άλλα άρθρα για φόρτωση

  NewsState({
    required this.articles,
    required this.isLoading,
    required this.hasMore,
  });

  // Constructor για αρχική κατάσταση
  factory NewsState.initial() => NewsState(
    articles: [],
    isLoading: false,
    hasMore: true,
  );

  // Μέθοδος για αλλαγή της κατάστασης (Immutability)
  NewsState copyWith({
    List<Article>? articles,
    bool? isLoading,
    bool? hasMore,
  }) {
    return NewsState(
      articles: articles ?? this.articles,
      isLoading: isLoading ?? this.isLoading,
      hasMore: hasMore ?? this.hasMore,
    );
  }
}

// 2. Ο Notifier (Η Λογική)
class NewsNotifier extends StateNotifier<NewsState> {
  static const int _startId = 2623;
  static const int _endId = 2000;
  static const int _pageSize = 20;

  NewsNotifier() : super(NewsState.initial());

  Future<void> fetchArticles({String? tag, bool isInitial = false}) async {
    if (!state.hasMore && !isInitial) return;
    if (state.isLoading) return;

    state = state.copyWith(isLoading: true);

    int currentLastId = state.articles.isNotEmpty ? state.articles.last.id : _startId + 1;
    
    if (isInitial || tag != null) {
      currentLastId = _startId + 1;
    }

    int startId = currentLastId - 1;
    int endId = startId - _pageSize;
    if (endId < _endId) endId = _endId;

    List<Article> newArticles = [];

    // Προσομοίωση φόρτωσης 20 άρθρων
    for (int id = startId; id > endId; id--) {
      // ΣΗΜΕΙΩΣΗ: Χρησιμοποιούμε μια dummy Apikey εδώ, αλλά πρέπει να είναι η δική σας.
      final response = await http.get(Uri.parse('https://www.hva.gr/api/article_details.php?id=$id&apikey=dFk9p3zvHBGdrt7ghDw3wT2mC4sL'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data is Map<String, dynamic> && data['title'] != null) {
          String simulatedTag;
          if (id % 4 == 0) {
            simulatedTag = 'Επιστημονικά';
          } else if (id % 4 == 1) {
            simulatedTag = 'Δελτία Τύπου';
          } else if (id % 4 == 2) {
            simulatedTag = 'Ανακοινώσεις της Δ.Ε.';
          } else {
            simulatedTag = 'Επαγγελματικά';
          }

          final article = Article.fromJson({
            'id': id,
            'title': data['title'] ?? 'Άρθρο χωρίς τίτλο',
            // ΣΗΜΕΙΩΣΗ: Η διεύθυνση εικόνας ενδέχεται να χρειαστεί προσαρμογή
            'imageUrl': 'https://www.hva.gr/${data['image_url']}', 
            'content': data['article_details'] ?? 'Δεν βρέθηκε περιεχόμενο.',
            'date': data['date'] ?? 'Άγνωστη ημερομηνία',
            'tag': simulatedTag,
          });
          
          if (tag == null || article.tag == tag) {
              newArticles.add(article);
          }
        }
      }
    }
    
    List<Article> updatedList = [];
    if (isInitial || tag != null) {
      updatedList = newArticles;
    } else {
      updatedList = [...state.articles, ...newArticles];
    }
    
    bool finalHasMore = newArticles.length == _pageSize && endId >= _endId; // Λίγο πιο ακριβής έλεγχος

    state = state.copyWith(
      articles: updatedList,
      isLoading: false,
      hasMore: finalHasMore,
  
    );}}