// lib/screens/home_screen.dart (ΔΙΟΡΘΩΜΕΝΟ)

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../widgets/gradient_background.dart';
import '../providers/news_provider.dart';
import 'detail_screen.dart'; 
import 'news_list_screen.dart'; 

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final topArticlesAsyncValue = ref.watch(top3NewsProvider);
    final primaryColor = Theme.of(context).primaryColor;

    // ΑΦΑΙΡΟΥΜΕ ΤΟ SCRAFFOLD, ΚΡΑΤΑΜΕ ΜΟΝΟ ΤΟ ΠΕΡΙΕΧΟΜΕΝΟ
    return GradientBackground(
      // Η padding ξεκινάει από 0,0,0,0 γιατί το AppBar θα είναι πλέον πάνω
      // Χρησιμοποιούμε padding 20.0 παντού για να μην κολλούν στα άκρα
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 3. Εμφάνιση Λογοτύπου Εφαρμογής (Asset)
            Center(
              child: Image.asset(
                'assets/images/hva_logo.png',
                height: 100,
                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : null,
              ),
            ),
            const SizedBox(height: 20),

            // Κεντρικός Τίτλος
            Text(
              'Καλώς ήρθατε!',
              style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                    color: Colors.white, 
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 40),

            // Τίτλος για τα Άρθρα
            Text(
              'Τελευταία Άρθρα',
              style: Theme.of(context).textTheme.headlineMedium!.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 20),

            // 4. Εμφάνιση των 3 Τελευταίων Άρθρων
            topArticlesAsyncValue.when(
              data: (articles) {
                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: articles.length,
                  itemBuilder: (context, index) {
                    final article = articles[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 15),
                      child: ListTile(
                        title: Text(article.title),
                        subtitle: Text(article.date),
                        trailing: const Icon(Icons.arrow_forward),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => DetailScreen(article: article),
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator(color: Colors.white)),
              error: (error, stack) => const Center(
                child: Text(
                  'Σφάλμα φόρτωσης άρθρων.', 
                  style: TextStyle(color: Colors.redAccent, fontSize: 16),
                ),
              ),
            ),

            const SizedBox(height: 40),

            // 5. Κουμπί Πλοήγησης
            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  // Push to NewsListScreen (αντί για αλλαγή καρτέλας, που είναι πιο περίπλοκο)
                  Navigator.of(context).push(
                       MaterialPageRoute(builder: (context) => const NewsListScreen()),
                  );
                },
                icon: const Icon(Icons.arrow_right_alt),
                label: const Text(
                  'Δείτε Όλα τα Νέα',
                  style: TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                  backgroundColor: Colors.white,
                  foregroundColor: primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            const SizedBox(height: 40),

            // 6. Λογότυπο Χορηγού (Asset)
            Center(
              child: Image.asset(
                'assets/images/sponsor_logo.png',
                height: 50,
              ),
            ),
          ],
        ),
      ),
    );
  }
}