// lib/screens/news_list_screen.dart (ΔΙΟΡΘΩΜΕΝΟ - ΑΦΑΙΡΕΣΗ Scaffold)

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../widgets/gradient_background.dart';
import '../providers/news_provider.dart'; 
import 'detail_screen.dart'; 
import '../widgets/article_card.dart';

// Χρησιμοποιούμε ConsumerStatefulWidget για να διαχειριστούμε το Scroll Controller 
class NewsListScreen extends ConsumerStatefulWidget {
  const NewsListScreen({super.key});

  @override
  ConsumerState<NewsListScreen> createState() => _NewsListScreenState();
}

class _NewsListScreenState extends ConsumerState<NewsListScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(newsProvider.notifier).fetchArticles(isInitial: true);
    });

    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent) {
      ref.read(newsProvider.notifier).fetchArticles();
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final newsState = ref.watch(newsProvider);
    final articles = newsState.articles;
    final isLoading = newsState.isLoading;
    final hasMore = newsState.hasMore;

    // ΑΦΑΙΡΟΥΜΕ ΤΟΝ ΕΞΩΤΕΡΙΚΟ Scaffold, 
    // αφού η NewsListScreen είναι child του Scaffold της MainNavigationScreen
    return GradientBackground( 
      child: articles.isEmpty && isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () => ref.read(newsProvider.notifier).fetchArticles(isInitial: true),
              child: ListView.builder(
                controller: _scrollController,
                itemCount: articles.length + (hasMore ? 1 : 0), 
                itemBuilder: (context, index) {
                  if (index == articles.length) {
                    return const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Center(child: CircularProgressIndicator()),
                    );
                  }
                  
                  final article = articles[index];
                  
                  return ArticleCard(
                    article: article,
                    onTap: () {
                       Navigator.of(context).push(
                         MaterialPageRoute(
                           builder: (context) => DetailScreen(article: article),
                         ),
                       );
                    },
                  );
                },
              ),
            ),
    ); // Τέλος της επιστροφής του GradientBackground
  }
}